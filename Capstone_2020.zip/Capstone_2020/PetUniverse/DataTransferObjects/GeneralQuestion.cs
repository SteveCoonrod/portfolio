﻿namespace DataTransferObjects
{
    public class GeneralQuestion
    {
        /// <summary>
        /// matchin the General Question 
        /// </summary>
        /// <remarks>
        /// by Awaab Elamin 4/2/2020
        /// Mohamed Elamin , 2/21/2020
        /// </remarks>
        public int QuestionID { get; set; }
        public string Description { get; set; }
    }
}
